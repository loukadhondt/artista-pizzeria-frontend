export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center bg-secondary overflow-hidden">
        {/* Abstract background elements to replace the exact image */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-10 left-10 w-64 h-64 bg-primary rounded-full blur-3xl mix-blend-multiply"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-accent rounded-full blur-3xl mix-blend-multiply"></div>
        </div>
        
        <div className="container mx-auto px-4 z-10 text-center">
          <span className="inline-block py-1 px-3 rounded-full bg-primary/20 text-primary font-bold text-sm tracking-widest mb-6 uppercase">
            Taste the Tradition
          </span>
          <h1 className="text-5xl md:text-7xl font-heading text-white mb-6 leading-tight">
            Artisanal Pizza, <br/>
            <span className="text-accent underline decoration-primary decoration-4 underline-offset-8">Delivered Fast.</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto mb-10">
            Hand-tossed crust, San Marzano tomatoes, and fresh mozzarella. Experience true Italian craftsmanship right at your doorstep.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="btn-primary text-lg px-8 py-4">Start Your Order</button>
            <button className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-md font-semibold hover:bg-white hover:text-secondary transition-colors duration-300 shadow-md">View Our Menu</button>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-20 bg-background" id="menu">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-heading mb-4">Explore Our Menu</h2>
            <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { title: 'Signature Pizzas', desc: 'Crafted with premium ingredients' },
              { title: 'Fresh Sides', desc: 'Garlic knots, salads, and more' },
              { title: 'Desserts', desc: 'Sweet treats to finish your meal' },
              { title: 'Beverages', desc: 'Sodas, craft beers, and wines' }
            ].map((cat, i) => (
              <div key={i} className="group cursor-pointer rounded-2xl p-8 bg-white shadow-sm border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-white transition-colors">
                  {/* Placeholder for SVG icon */}
                  <span className="text-2xl">🍕</span>
                </div>
                <h3 className="text-xl font-bold mb-2">{cat.title}</h3>
                <p className="text-gray-500 text-sm mb-4">{cat.desc}</p>
                <span className="text-primary font-semibold text-sm group-hover:underline">Browse Items &rarr;</span>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Dynamic CTA */}
      <section className="py-24 bg-primary text-white text-center">
         <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-5xl font-heading mb-6">Hungry Yet?</h2>
            <p className="text-lg md:text-xl text-primary-light max-w-2xl mx-auto mb-10">
              Join thousands of happy customers who trust Artista Pizzeria for their weekly slice of heaven. Order now and get 10% off your first delivery.
            </p>
            <button className="bg-white text-primary px-10 py-4 rounded-md font-bold text-lg hover:bg-gray-100 transition shadow-lg transform hover:scale-105">
              Order Online Now
            </button>
         </div>
      </section>
    </div>
  );
}
