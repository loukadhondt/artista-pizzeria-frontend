import type { Metadata } from "next";
import { Inter, Oswald } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: '--font-inter' });
const oswald = Oswald({ subsets: ["latin"], variable: '--font-oswald' });

export const metadata: Metadata = {
  title: "Artista Pizzeria - Authentic Artisanal Pizza",
  description: "Order the best artisanal pizza online. Fast delivery, fresh ingredients.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${inter.variable} ${oswald.variable} antialiased flex flex-col min-h-screen`}>
        {/* Navigation Bar Placeholder */}
        <header className="fixed w-full z-50 bg-white/90 backdrop-blur-md shadow-sm border-b border-gray-100 transition-all duration-300">
          <div className="container mx-auto px-4 h-20 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-3xl font-heading font-bold text-primary tracking-tight">ARTISTA</span>
            </div>
            <nav className="hidden md:flex gap-8 font-semibold text-secondary">
              <a href="#menu" className="hover:text-primary transition-colors">Our Menu</a>
              <a href="#about" className="hover:text-primary transition-colors">Our Story</a>
              <a href="#locations" className="hover:text-primary transition-colors">Locations</a>
            </nav>
            <div className="flex gap-4">
              <button className="text-secondary hover:text-primary transition-colors font-medium">Login</button>
              <button className="btn-primary flex items-center gap-2">
                Order Now
              </button>
            </div>
          </div>
        </header>

        <main className="flex-grow pt-20">
          {children}
        </main>

        <footer className="bg-secondary text-white py-12">
          <div className="container mx-auto px-4 grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-2xl font-bold mb-4 font-heading text-primary">ARTISTA</h3>
              <p className="text-gray-300 text-sm">Authentic artisanal pizza made with passion and the finest imported Italian ingredients.</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-primary">Menu</a></li>
                <li><a href="#" className="hover:text-primary">Track Order</a></li>
                <li><a href="#" className="hover:text-primary">Careers</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>456 Main St, New York</li>
                <li>555-0198</li>
                <li>hello@artistapizzeria.com</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Operating Hours</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>Mon-Thu: 10:00 - 22:00</li>
                <li>Fri-Sat: 10:00 - 23:00</li>
                <li>Sun: 11:00 - 21:00</li>
              </ul>
            </div>
          </div>
          <div className="container mx-auto px-4 mt-8 pt-8 border-t border-gray-700 text-center text-sm text-gray-400">
            © {new Date().getFullYear()} Artista Pizzeria. All rights reserved. Powered by the SaaS Platform.
          </div>
        </footer>
      </body>
    </html>
  );
}
